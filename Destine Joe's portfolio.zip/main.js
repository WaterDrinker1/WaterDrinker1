
const toggleMenu = document.getElementById('toggle-menu');
let navMenu = document.getElementById('nav-menu')
let closeMenu = document.getElementById('close-menu')

let whatsapp = document.querySelector('#whatsapp');
let messenger = document.querySelector('#messenger');
let messengerSpan = document.querySelector('#messenger-span');
let whatsappSpan = document.querySelector('#whatsapp-span')

let menu1 = document.getElementById('main-menu');

const i1 = document.getElementById('i1')
const i2 = document.getElementById('i2')
const i3 = document.getElementById('i3')
const i4 = document.getElementById('i4')

const scrollContainer = document.getElementById('projects-mum')

const leftBtn = document.getElementById('left-btn')
const rightBtn = document.getElementById('right-btn')
const aboutLink = document.getElementById('about-link')
const about = document.getElementById('about')

let windWidth = window.innerWidth

let counter = 1

const projects = document.querySelectorAll('.projects')

leftBtn.onclick = () => {
  
  windWidth <= 412 ? scrollContainer.scrollLeft -= 360 : scrollContainer.scrollLeft -= 800
  
  counter == 1 ? counter -=0 : counter -=1
  
  switch (true) {
    case counter == 1:
      i1.style.color = '#FF8228'
      i2.style.color = 'white'
      i3.style.color = 'white'
      i4.style.color = 'white'
      break;
    case counter == 2:
      i1.style.color = 'white'
      i2.style.color = '#FF8228'
      i3.style.color = 'white'
      i4.style.color = 'white'
      break;
    case counter == 3:
      i1.style.color = 'white'
      i2.style.color = 'white'
      i3.style.color = '#FF8228'
      i4.style.color = 'white'
      break;
  }
}

rightBtn.onclick = () => {
  windWidth <= 412 ? scrollContainer.scrollLeft += 360 :scrollContainer.scrollLeft += 800
  
  counter == 4 ? counter += 0 : counter ++
  
  switch (true) {
    case counter == 2:
      i1.style.color = 'white'
      i2.style.color = '#FF8228'
      i3.style.color = 'white'
      i4.style.color = 'white'
      break;
    case counter == 3:
      i1.style.color = 'white'
      i2.style.color = 'white'
      i3.style.color = '#FF8228'
      i4.style.color = 'white'
      break;
    case counter == 4:
      i1.style.color = 'white'
      i2.style.color = 'white'
      i3.style.color = 'white'
      i4.style.color = '#FF8228'
      break;
  }

}

function hovered(elem) {

  if (elem.id === 'messenger') {
    
    if(windWidth <= 450){
      
      elem.style.width = '70%'
      
    } else{
      
      elem.style.width = '40%'
      
    }
    
  setTimeout(() => {
      messengerSpan.style.display = 'flex';
    }, 60)
     

  } else {
    
    if (windWidth <= 450) {
    
      elem.style.width = '70%'
    
    } else {
    
      elem.style.width = '40%'
    
    }

    setTimeout(() => {
      whatsappSpan.style.display = 'flex';

    }, 60)
  }

}

function notHovered(elem) {
  
  windWidth <= 450 ? elem.style.width = '40%' : elem.style.width ='20%'

  setTimeout(() => {
    whatsappSpan.style.display = 'none';
    messengerSpan.style.display = 'none';
  }, 60)
}

toggleMenu.onclick = () =>{
  navMenu.style.display = 'flex'
}
closeMenu.onclick = () =>{
  navMenu.style.display = 'none'
}

aboutLink.addEventListener('click', () => {
  about.scrollIntoView(false)
})
